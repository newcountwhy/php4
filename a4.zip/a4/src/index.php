<?php 
echo "I am a PHP page running on four containers: NginX + PHP-PFM + MariaDB + Redis!";
phpinfo();
?>
